import {useEffect, useState} from 'react'
import './app.css'
import SearchResult from './components/SearchResult/SearchResult';

export const BASE_URL= "http://localhost:9000";

const App = () => {

  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [filteredData, setFilteredData] = useState(null)
  const [selectedBtn, setSelectedBtn] = useState("all")

    useEffect(()=>{
      const fetchFoodeData=async()=>{
        setLoading(true)
        try{
        const response = await fetch(BASE_URL);
    
        const json =await response.json();
        setData(json)  
        setLoading(false)
        setFilteredData(json)
        
        }catch(error)
        {
          setError("Unable to fetch data")
        }
      };
      fetchFoodeData();
    },[])

    const searchfood = (e) => {
      const searchValue = e.target.value;
          console.log(searchValue)

          if(searchValue === "")
          {
            setFilteredData(null)
          }

         

          setFilteredData(filter);

    }
    
    console.log(data)

    const filteredFood = (type)=>{
      if(type==="all"){
        setFilteredData(data)
        setSelectedBtn("all")
        return;
      }
      const filter = data?.filter((food)=>
      food.type.toLowerCase().includes(type.toLowerCase()));

      setFilteredData(filter)
      setSelectedBtn(type);

    }

    const filterBtns = [
      {
        name: "All",
        type: "all",
      },
      {
        name: "Breakfast",
        type: "breakfast",
      },
      {
        name: "Lunch",
        type: "lunch",
      },
      {
        name: "Dinner",
        type: "dinner",
      },
    ];

  if (error)
  return <div>{error}</div>

  if(loading)
  return <div>loading................ruk jaa</div>

  return (
  <div className='Container'>
      <div className='TopContainer'>
        <div className="logo">
          <img src="/logo.svg" alt="logo" />
        </div>


      <div className="search">
        <input onChange={searchfood} placeholder='Search Food'/>
      </div>


      </div>
      <div className="FilterContainer">
      {filterBtns.map((value)=>(
        <button className='Button' isSelected ={selectedBtn===value.type}
        key ={value.name}
        onClick={()=>filteredFood(value.type)}>
          {value.name}
        </button>
      ))}
      </div>
      
      <SearchResult data={filteredData}/>

    </div>
  )
}

export default App

