import React from 'react'
import Nav from './components/Nav/Nav'
import './App.css'
import ContactHeader from './components/Contactheader/ContactHeader'
import ContactForm from './components/ContactForm/ContactForm'

const App = () => {
  return (
    <div>
      <Nav/>
      <ContactHeader/>
      <ContactForm/>
    </div>
  )
}

export default App
