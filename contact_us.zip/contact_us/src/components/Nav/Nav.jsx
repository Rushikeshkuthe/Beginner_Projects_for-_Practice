import React from 'react'
import logo from '../../assets/logo.png'
import '../Nav/Nav.css'

const Nav = () => {
  return (
    <nav className='container'>
        <div className='logo'>
            <img src={logo} alt="logo" />
        </div>
        <ul>
            <li href='#'>Home</li>
            <li href='#'>About</li>
            <li href='#'>Contact</li>
        </ul>
    </nav>
  )
}

export default Nav
