import React, { useState } from "react";
import "../ContactForm/ContactForm.css";
import Button from "../Button/Button";
import { BiMessageAltDetail } from "react-icons/bi";
import { BiPhoneCall } from "react-icons/bi";
import { FiMail } from "react-icons/fi";
import hero from '../../assets/hero.png'


const ContactForm = () => {
    const [name, setName] = useState("Rishi");
    const [email, setEmail] = useState("qwerty@gmail.com");
    const [text, setText] = useState("Hi ,Frontend devloper here");


    const onSubmit=(e)=>{

      e.preventDefault();
      setName(e.target[0].value);
      setEmail(e.target[1].value);
      setText(e.target[2].value);

    }

  return (
    <section className="container">
      <div className="contact_form">
        <div className="top-btn">
          <Button
            text="VIA SUPPORT CHAT"
            icon={<BiMessageAltDetail fontSize="24px" />}
          />

          <Button text="VIA CALL" icon={<BiPhoneCall fontSize="24px" />} />
        </div>
        <Button
          isOutline={true}
          text="VIA EMAIL FORM"
          icon={<FiMail fontSize="24px" />}
        />

        <form onSubmit={onSubmit}>
          <div className="form_control">
            <label htmlFor="name">Name</label>
            <input type="text" name="name" />
          </div>
          <div className="form_control">
            <label htmlFor="email">Email</label>
            <input type="email" name="email" />
          </div>
          <div className="form_control">
            <label htmlFor="name">Text</label>
           <textarea name="text" rows="8"/>
          </div>
          <div style={{display:"flex",justifyContent:"end"}}>
            <Button text ="SUBMIT BUTTON"/>
          </div>

        <div>{name + " " + email + " " + text }</div>
        </form>
      </div>

      <div className="contactImage">
        <img src={hero} alt="contact image" />
      </div>
    </section>
  );
};

export default ContactForm;
